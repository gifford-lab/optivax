This folder Larger_version_modified is exactly the same as the folder larger_version, 
with the only difference being that the reference sequence >Wuhan-Hu-1/2019 has been 
added to the top as it was not in the original version of the file.